package sg.edu.nus.demo.models;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Course {
    @Id
    private int id;
    private String courseCode;
	private String name;
    private int duration;
    private int credit;

    @ManyToOne
    private Department department;
    
    public Course() {
  		super();
  		// TODO Auto-generated constructor stub
  	}

	public Course(int id, String courseCode, String name, int duration, int credit, Department department) {
		super();
		this.id = id;
		this.courseCode = courseCode;
		this.name = name;
		this.duration = duration;
		this.credit = credit;
		this.department = department;
	}
	
    
    
    
}