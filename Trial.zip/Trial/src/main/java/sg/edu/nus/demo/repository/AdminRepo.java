package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.models.Admin;

public interface AdminRepo extends JpaRepository<Admin,Integer>{

	Admin findByUsername(String username);

}
