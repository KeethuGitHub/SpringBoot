package sg.edu.nus.demo.models;


import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class LeaveMngmnt {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private Date startDate;
	private Date endDate;
	private String reason;
	private String leavestatus;
	
	@ManyToOne
	@JoinColumn(name = "student_id")
	private Student student;

	public LeaveMngmnt() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LeaveMngmnt(int id,Date startDate, Date endDate, String reason,String leavestatus, Student student) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.reason = reason;
		this.leavestatus = leavestatus;
		this.student = student;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getLeavestatus() {
		return leavestatus;
	}

	public void setLeavestatus(String leavestatus) {
		this.leavestatus = leavestatus;
	}
	
	
}
