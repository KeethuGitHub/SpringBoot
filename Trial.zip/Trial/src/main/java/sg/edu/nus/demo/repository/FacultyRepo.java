package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.demo.models.Faculty;

public interface FacultyRepo extends JpaRepository<Faculty,Integer>{

//	@Query("select f from Faculty f where f.userId = :userId")
//	Faculty findByuserid(@Param("userId") String userId);
}
