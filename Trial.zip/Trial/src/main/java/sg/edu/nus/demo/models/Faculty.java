package sg.edu.nus.demo.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Faculty {
	 @Id
	    private int id;
	 private String userid;
	    private String password;
	    private String firstName;
	    private String lastName;
	    private String address;
	    private String contact;
	    private String dateOfBirth;
	    private String email;
	    private char gender;
	private static int numOfFaculty = 0;

	@ManyToOne
    private Department department;
	
    public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Faculty(int id,String userid, String password, String firstName, String lastName, String address, String contact,
			String dateOfBirth, String email, char gender, Department department) {
		super();
		this.id = id;
		this.userid = userid;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.contact = contact;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.gender = gender;
		this.department = department;
	}
    
}