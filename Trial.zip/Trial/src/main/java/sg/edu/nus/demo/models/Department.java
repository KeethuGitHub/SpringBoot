package sg.edu.nus.demo.models;

import java.util.Collection;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
    @Id
    private int id;
    private String name;

    @OneToMany(targetEntity=Course.class,mappedBy="department")
    private Collection Courses;
    
    @OneToMany(targetEntity=Faculty.class, mappedBy="department")
    private List<Faculty> faculties;
    
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Department(int id, String name, Collection courses, List<Faculty> faculties) {
		super();
		this.id = id;
		this.name = name;
		Courses = courses;
		this.faculties = faculties;
	}
	
}