package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.models.Enrollment;

public interface EnrollRepo extends JpaRepository<Enrollment,Integer> {

}
