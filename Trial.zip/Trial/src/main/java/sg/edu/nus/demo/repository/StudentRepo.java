package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.demo.models.LeaveMngmnt;
import sg.edu.nus.demo.models.Student;

public interface StudentRepo extends JpaRepository<Student,Integer>
{

	@Query("SELECT s FROM Student s WHERE s.username = :username")
    public Student findByUsername(@Param("username") String username);

	public void save(LeaveMngmnt l1);


}
