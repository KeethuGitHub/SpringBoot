package sg.edu.nus.demo.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sg.edu.nus.demo.Services.LeaveService;
import sg.edu.nus.demo.Services.StudentService;
import sg.edu.nus.demo.models.Admin;
import sg.edu.nus.demo.models.Course;
import sg.edu.nus.demo.models.Department;
import sg.edu.nus.demo.models.Enrollment;
import sg.edu.nus.demo.models.Faculty;
import sg.edu.nus.demo.models.LeaveMngmnt;
import sg.edu.nus.demo.models.Semester;
import sg.edu.nus.demo.models.Student;
import sg.edu.nus.demo.repository.FacultyRepo;
import sg.edu.nus.demo.repository.LeaveRepo;
import sg.edu.nus.demo.repository.SemesterRepo;
import sg.edu.nus.demo.repository.StudentRepo;
import sg.edu.nus.demo.repository.AdminRepo;
import sg.edu.nus.demo.repository.CourseRepo;
import sg.edu.nus.demo.repository.DepartmentRepo;
import sg.edu.nus.demo.repository.EnrollRepo;


@Controller
@RequestMapping("/basic")
public class BasicController {

	private static final Logger log = LoggerFactory.getLogger(BasicController.class);
	private StudentService stuservice;
	private LeaveService lservice;
	
	@Autowired
    public void setStudentService(StudentService sService) {
        this.stuservice = sService;
    }
	
	@Autowired
    public void setLeaveService(LeaveService lservice) {
        this.lservice = lservice;
    }

	@Autowired
	private FacultyRepo facultyrepo;
	@Autowired
	private DepartmentRepo departmentrepo;
	@Autowired
	private StudentRepo studentrepo;
	@Autowired
	private SemesterRepo semrepo;
	@Autowired
	private CourseRepo courserepo;
	@Autowired
	private EnrollRepo enrolrepo;
	@Autowired
	private LeaveRepo leaverepo;
	@Autowired
	private AdminRepo adminrepo;

	@RequestMapping("/")
	public String dbValues(){
		Department d = new Department(1,"ISS");
		Department d1 = new Department(2,"Computing");
		Department d2 = new Department(3,"Bschool");
		departmentrepo.save(d);
		departmentrepo.save(d1);
		departmentrepo.save(d2);
		
		Faculty f1 = new Faculty(1,"F1","qwerty","Yuan","Kwan","12,Kent ridge","123456","05/01/60","keethu@gmail.com",'M',d);
		facultyrepo.save(f1);
		Faculty f2 = new Faculty(2,"F2","faculty2","Sam","andre","12,Kent ridge","123456","05/01/80","keethu@gmail.com",'F',d1);
		facultyrepo.save(f2);
		Faculty f3 = new Faculty(1,"F3","password","Hari","natha","12,Kent ridge","123456","05/01/60","keethu@gmail.com",'M',d2);
		facultyrepo.save(f3);
		List<Semester> semList = new ArrayList<Semester>();
		
		
		Student s1 = new Student(1,"S001","qwerty","Keerthana","Kan","12,Kent ridge","123456","05/01/96","keethu@gmail.com",'F',"compsci",7.8f,"Student");
		studentrepo.save(s1);
		Student s2 = new Student(2,"S002","qwerty","Saif","Mohd","12,Kent ridge","123456","05/01/96","keethu@gmail.com",'F',"IT",7.5f,"Student");
		studentrepo.save(s2);
		Student s3 = new Student(1,"S003","qwerty","Adhi","aman","12,Kent ridge","123456","05/01/96","keethu@gmail.com",'F',"compsci",9.5f,"Student");
		studentrepo.save(s3);
		Semester sem1 = new Semester(1,1,s1);
		Semester sem2 = new Semester(2,2,s1);
		Semester sem3 = new Semester(3,4,s1);
		Semester sem4 = new Semester(4,3,s1);
		semrepo.saveAll(Arrays.asList(sem1,sem2,sem3,sem4));
		
		s1.setSemesters(Arrays.asList(sem1,sem2,sem3));
		s2.setSemesters(Arrays.asList(sem3,sem2,sem4));
		s3.setSemesters(Arrays.asList(sem1,sem2,sem4));
		
		sem1.setStudent(s1);
		sem2.setStudent(s1);
		sem3.setStudent(s1);
		
		sem2.setStudent(s2);
		sem3.setStudent(s2);
		sem4.setStudent(s2);
		
		sem1.setStudent(s3);
		sem2.setStudent(s3);
		sem4.setStudent(s3);
		
		//sem2.setStudent(s);
//		semList.add(sem1);
//		semList.add(sem2);
//		semList.add(sem3);
//		semList.add(sem4);
		studentrepo.save(s1);
		studentrepo.save(s2);
		studentrepo.save(s3);
	
		Course c1 = new Course(1,"SA4105","Web Application Development", 50, 6,d);
		Course c2 = new Course(2,"SA4104", "Software Engineering", 70, 4, d1);
		Course c3 = new Course(3,"SA4018", "Mobile Application Development", 80, 8,d);
		Course c4 = new Course(4,"SA4012", "Foundation", 86, 6, d1);
		courserepo.saveAll(Arrays.asList(c1,c2,c3,c4));
				
//		Faculty fac1 = facultyrepo.findByuserid("F1");
//		Semester semester1 = semrepo.findById(4).get();
		Enrollment enr1 = new Enrollment(1, "completed",sem1);
		enrolrepo.save(enr1);	
		Enrollment enr2 = new Enrollment(2, "completed",sem2);
		enrolrepo.save(enr2);	
		Enrollment enr3 = new Enrollment(3, "completed",sem3);
		enrolrepo.save(enr3);	
		
		Admin a1 = new Admin(1,"A001","qwerty","admin","admin","12,Kent ridge","123456","05/01/96","keethu@gmail.com",'F');
		adminrepo.save(a1);
		
		return "welcom";
	}
	@GetMapping("/login")
	public String loginPage(HttpSession session,Model model){	
		model.addAttribute("user",new Student());	
	//	session.setAttribute("sessionUser", new Student());
	//	model.addAttribute("user", session.getAttribute("sessionUser"));
		return "login";
	}
	
	@RequestMapping(value= "/home",method = RequestMethod.POST)
	public String login(@ModelAttribute("user") Student user,Model model, HttpSession session){
//		Student s = studentrepo.findByUsername(user.getUsername());		
//		if(s.getPassword().equals(user.getPassword()))
//		{
//			model.addAttribute("student",s);
//			session.setAttribute("stu", s);
//			return "studenthome";
//		}
	//	 String username = ((Student) session.getAttribute("sessionUser")).getUsername();
		char prefix = user.getUsername().charAt(0);
		switch (prefix) {
		case 'A':
			Admin a = adminrepo.findByUsername(user.getUsername());
			if (a.getPassword().equals(user.getPassword())) {
				model.addAttribute("admin", a);
				return "admin";
			}

//		case 'F':
//			Faculty f = facultyrepo.findByUsername(user.getUsername());
//			if (f.getPassword().equals(user.getPassword())) {
////				log.info("i am inside.hello");
////				log.info(f.getPassword());
////				log.info(user.getPassword());
//				return "redirect:/faculty";
//			}

		case 'S':
		//	 Student s = (Student) session.getAttribute("sessionUser");
		//	 String passwrd = ((Student) session.getAttribute("sessionUser")).getPassword();
			Student s = studentrepo.findByUsername(user.getUsername());
			if (s.getPassword().equals(user.getPassword())) {
				model.addAttribute("student",s);
				return "studenthome";
			}
		default:
			return "redirect:/login";
		}
	}
	@GetMapping("/details")
	public String detailsPage(Model model,HttpSession session){
	//	Student s = (Student) session.getAttribute("sessionUser");
		Student s = studentrepo.findByUsername("S002");
		model.addAttribute("student",s);
		return "studenthome";
	}
	
	@GetMapping("/leave")
	public String LeavePage(Model model){
		LeaveMngmnt l1 = new LeaveMngmnt();
		Student s = studentrepo.findByUsername("S002");
		model.addAttribute("leave",l1);
		return "leaveForm";
	}
	@RequestMapping(value= "/applyleave",method = RequestMethod.POST)
	public String applyleavePage(@ModelAttribute("leave") LeaveMngmnt leave){
		List<LeaveMngmnt> leaves = new ArrayList<LeaveMngmnt>();
		leave.setLeavestatus("pending");
		leaves.add(leave);
		Student s = studentrepo.findByUsername("S002");
		leave.setStudent(s);
		s.setLeaves(leaves);
		stuservice.save(leave);
		lservice.save(leave);
		return "leaveForm";
	}
	@GetMapping("/logout")
	public String getLogoutPage(HttpSession session) {
		 session.invalidate();
		return "welcom";
	}
	
	@GetMapping("/viewLeave")
	public String leavePage(Model model) {
		List<LeaveMngmnt> leaves = new ArrayList<LeaveMngmnt>();
		leaves.addAll(lservice.findAllByleavestatus("pending"));
		model.addAttribute("leaves",leaves);
		return "leavedetails";
	}
	
	@RequestMapping("/approve/{id}")
	public String approveLeave(@PathVariable("id") Integer id, Model model)
	{
		LeaveMngmnt l = lservice.findById(id);
		l.setLeavestatus("Approved");
		stuservice.save(l);
		lservice.save(l);
		model.addAttribute("leaves",lservice.findAll());
		return "adminViewLeave";
	}
	@RequestMapping("/reject/{id}")
	public String rejectLeave(@PathVariable("id") Integer id, Model model)
	{
		LeaveMngmnt l = lservice.findById(id);
		l.setLeavestatus("Rejected");
		stuservice.save(l);
		lservice.save(l);
		model.addAttribute("leaves",lservice.findAll());
		return "adminViewLeave";
	}
	@GetMapping("/stuviewLeave")
	public String stuleavePage(Model model) {
		List<LeaveMngmnt> leaves = new ArrayList<LeaveMngmnt>();
		LeaveMngmnt l1 = new LeaveMngmnt();
		Student s = studentrepo.findByUsername("S002"); //session
		leaves = lservice.findAllByStudent_id(s.getId());   
		model.addAttribute("leaves",leaves);
		return "studentViewLeave";
		 
	}
	@GetMapping("/viewLeavehistory")
	public String leavehistory(Model model) {
		List<LeaveMngmnt> leaves = new ArrayList<LeaveMngmnt>();
		leaves.addAll(lservice.findAllByStatus("pending"));
		model.addAttribute("leaves",leaves);
	return "adminViewLeave";
	}
}