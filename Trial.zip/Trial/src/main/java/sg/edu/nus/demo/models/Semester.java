package sg.edu.nus.demo.models;

import java.util.Collection;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Semester {
    @Id
    private int id;
    private int semNumber;
 //   private int student_id;
    
    
    @ManyToOne
 //   @JoinColumn(name="student_id")
    private Student student;
    
    @OneToMany(targetEntity = Enrollment.class, mappedBy = "semester")
	private Collection enrollments;

	public Semester() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Semester(int id, int semNumber, Student student) {
		super();
		this.id = id;
		this.semNumber = semNumber;
		this.student = student;
	}
	public Semester(int id, int semNumber, Student student, Collection enrollments) {
		super();
		this.id = id;
		this.semNumber = semNumber;
		this.student = student;
		this.enrollments = enrollments;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSemNumber() {
		return semNumber;
	}

	public void setSemNumber(int semNumber) {
		this.semNumber = semNumber;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Collection getEnrollments() {
		return enrollments;
	}

	public void setEnrollments(Collection enrollments) {
		this.enrollments = enrollments;
	}
	
}