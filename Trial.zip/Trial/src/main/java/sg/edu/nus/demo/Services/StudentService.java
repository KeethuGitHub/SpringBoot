package sg.edu.nus.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sg.edu.nus.demo.models.LeaveMngmnt;
import sg.edu.nus.demo.models.Student;
import sg.edu.nus.demo.repository.StudentRepo;
@Service
public class StudentService 
{
	private StudentRepo studentRepo;
	
	@Autowired
	    public void setStudentRepository(StudentRepo studentRepo) {
	        this.studentRepo = studentRepo;
	    }

	public Student findByUsername(String username) {
		// TODO Auto-generated method stub
		  return studentRepo.findByUsername(username);
	}

	public void save(LeaveMngmnt l1) {
		studentRepo.save(l1);
		
	}



}
