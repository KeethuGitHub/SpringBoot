package sg.edu.nus.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import sg.edu.nus.demo.Services.StudentService;
import sg.edu.nus.demo.models.Student;
import sg.edu.nus.demo.repository.StudentRepo;

@Controller
@RequestMapping("/student")
public class StudentController {
	 
	 @RequestMapping("/home")
		public String login(Model model){
			StudentService s = new StudentService();
			Student student = s.findByUsername("S13");
			model.addAttribute("student",student);		
			return "home";
		}
	  
}
