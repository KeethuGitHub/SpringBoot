package sg.edu.nus.demo.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Enrollment {

    @Id
    private int id;
    private String status;
    
    @ManyToOne
    private Semester semester;

	public Enrollment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Enrollment(int id, String status, Semester semester) {
		super();
		this.id = id;
		this.status = status;
		this.semester = semester;
	}
    
}