package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.models.Semester;
public interface SemesterRepo extends JpaRepository<Semester, Integer>{

}
