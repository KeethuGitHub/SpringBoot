package sg.edu.nus.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.demo.models.LeaveMngmnt;
public interface LeaveRepo extends JpaRepository<LeaveMngmnt,Integer> {
	
	LeaveMngmnt findById(@Param("id") String id);

	Optional<LeaveMngmnt> findByStudent_Id(int id);

	List<LeaveMngmnt> findAllByStudent_Id(int id);

	@Query("select c from LeaveMngmnt c where c.leavestatus = :status")
	List<LeaveMngmnt> findAllByleavestatus(String status);

	@Query("select c from LeaveMngmnt c where c.leavestatus != :status")
	List<LeaveMngmnt> findAllByStatus(String status);
}
