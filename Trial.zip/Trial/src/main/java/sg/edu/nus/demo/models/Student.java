package sg.edu.nus.demo.models;

import java.util.Collection;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Student {
	@Id
	private int id;
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String address;
	private String contact;
	private String dateOfBirth;
	private String email;
	private char gender;
	private static int numOfStudent = 0;

	private String major;
	private float cgpa;
	private String studentStatusId;

	@OneToMany(targetEntity = Semester.class, mappedBy = "student")
	private Collection semesters;
	
	@OneToMany(targetEntity = LeaveMngmnt.class, mappedBy = "student")
	private Collection leaves;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Student(int id, String username, String password, String firstName, String lastName, String address,
			String contact, String dateOfBirth, String email, char gender, String major, float cgpa,
			String studentStatusId, Collection semesters, Collection leaves) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.contact = contact;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.gender = gender;
		this.major = major;
		this.cgpa = cgpa;
		this.studentStatusId = studentStatusId;
		this.semesters = semesters;
		this.leaves = leaves;
	}


	public Collection getLeaves() {
		return leaves;
	}


	public void setLeaves(Collection leaves) {
		this.leaves = leaves;
	}


	public Student(int id,String username, String password, String firstName, String lastName, String address, String contact,
			String dateOfBirth, String email, char gender, String major, float cgpa, String studentStatusId) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.contact = contact;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.gender = gender;
		this.major = major;
		this.cgpa = cgpa;
		this.studentStatusId = studentStatusId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public static int getNumOfStudent() {
		return numOfStudent;
	}

	public static void setNumOfStudent(int numOfStudent) {
		Student.numOfStudent = numOfStudent;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public float getCgpa() {
		return cgpa;
	}

	public void setCgpa(float cgpa) {
		this.cgpa = cgpa;
	}

	public String getStudentStatusId() {
		return studentStatusId;
	}

	public void setStudentStatusId(String studentStatusId) {
		this.studentStatusId = studentStatusId;
	}

	public Collection getSemesters() {
		return semesters;
	}

	public void setSemesters(Collection semesters) {
		this.semesters = semesters;
	}
	
	

}
