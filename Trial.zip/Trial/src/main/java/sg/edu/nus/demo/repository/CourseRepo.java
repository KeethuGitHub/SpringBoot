package sg.edu.nus.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.edu.nus.demo.models.Course;

public interface CourseRepo extends JpaRepository<Course,Integer> {

	Course findBycourseCode(String string);

}
