package sg.edu.nus.demo.Services;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sg.edu.nus.demo.models.LeaveMngmnt;
import sg.edu.nus.demo.repository.LeaveRepo;

@Service
public class LeaveService {

private LeaveRepo leaverepo;
	
	@Autowired
	    public void setLeaveRepository(LeaveRepo leaverepo) {
	        this.leaverepo = leaverepo;
	    }

	public void save(LeaveMngmnt leave) {
		leaverepo.save(leave);
		
	}

	public List<LeaveMngmnt> findAll() {
		return leaverepo.findAll();
		
	}

	public LeaveMngmnt findById(int id) {
		// TODO Auto-generated method stub
		return leaverepo.findById(id).get();
	}

	public List<LeaveMngmnt> findAllByStudent_id(int id) {
		// TODO Auto-generated method stub
		return leaverepo.findAllByStudent_Id(id);
	}

	public List<LeaveMngmnt> findAllByleavestatus(String status) {
		// TODO Auto-generated method stub
		return leaverepo.findAllByleavestatus(status);
	}

	public List<LeaveMngmnt> findAllByStatus(String s) {
		// TODO Auto-generated method stub
		return leaverepo.findAllByStatus(s);
	}
}
